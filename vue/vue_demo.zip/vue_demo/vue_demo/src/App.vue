<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
@import "./assets/css/main.css";
@import "./assets/css/color-dark.css";     /*深色主题*/
</style>
