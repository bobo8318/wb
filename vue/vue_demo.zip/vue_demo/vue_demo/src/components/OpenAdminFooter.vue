<template>
    <div>
        页面底部
    </div>
</template>

<script>
export default {
  name: 'blogFooter'
}
</script>
