<template>
    <div id="blogHeader">
        页面头部
    </div>
</template>

<script>
export default {
  name: 'blogHeader'
}
</script>
